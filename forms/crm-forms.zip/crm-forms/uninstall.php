<?php
/**
 * Removes the plugin's two options. Nothing else is stored: forms and
 * submissions live in the CRM, so uninstalling here never destroys data.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'crm_forms_base_url' );
delete_option( 'crm_forms_api_style' );
