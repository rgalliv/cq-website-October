=== CRM Forms ===
Contributors: rgalliv
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPL-2.0-or-later

Embed native CRM forms using [crm_form slug="cq-website-inquiry"].

== Installation ==
Upload crm-forms.zip to a WordPress installation that permits custom plugins.
Activate, then open Settings > CRM Forms. Use https://crm-crane.vercel.app
and the Vercel functions API style for the existing Business CRM.
Place the shortcode in a Shortcode block or supported page-builder widget.
Requires HTTPS and a current browser with Web Crypto.

== Data and consent ==
The plugin sends entries directly to the configured CRM only when submitted.
It does not send entries to Web3Forms. It stores only a payload hash, request
UUID and receipt in browser session storage, not entered contact details.
Form fields, recipients and consent policy are controlled in the CRM.
Required inquiry permission and optional marketing consent stay separate.

Durable retry deduplication requires the existing atomic resourceCapture form
contract; cq-website-inquiry has this enabled. Legacy non-atomic CRM forms
retain their existing behavior. Do not claim durable replay protection for them.

== Changelog ==
= 1.1.0 =
Bundled local renderer, stable UUID retries, pending guard, accessible errors,
receipt-backed atomic success, unique labels across multiple forms, safer
origin settings and late page-builder refresh support.
