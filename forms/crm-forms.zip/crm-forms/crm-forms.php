<?php
/**
 * Plugin Name:       CRM Forms
 * Description:       Embed forms built in your CRM anywhere in WordPress with a [crm_form] shortcode.
 * Version:           1.1.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * License:           GPL-2.0-or-later
 * Text Domain:       crm-forms
 *
 * Why this plugin exists rather than "just paste the embed snippet":
 * WordPress strips <script> tags from post content for any user without the
 * unfiltered_html capability — which is every user on WordPress.com, on most
 * multisite installs, and any Editor/Author role. Pasting the snippet into a
 * Custom HTML block appears to work in the editor and then silently renders
 * nothing on the front end. Enqueuing the script from a plugin is the only
 * way that holds up across hosts and roles.
 */

defined( 'ABSPATH' ) || exit;

const CRM_FORMS_VERSION     = '1.1.0';
const CRM_FORMS_OPT_BASE    = 'crm_forms_base_url';
const CRM_FORMS_OPT_STYLE   = 'crm_forms_api_style';
const CRM_FORMS_HANDLE      = 'crm-forms-embed';

/**
 * The embed loader URL differs by which adapter the CRM was deployed with.
 */
function crm_forms_embed_src() {
	$base = untrailingslashit( (string) get_option( CRM_FORMS_OPT_BASE, '' ) );
	if ( '' === $base ) {
		return '';
	}
	$style = get_option( CRM_FORMS_OPT_STYLE, 'nextjs' );

	return 'vercel' === $style
		? $base . '/api/crm-form?embed=1'
		: $base . '/api/crm/embed';
}

/**
 * Register the loader without printing it. Enqueueing happens only when a
 * shortcode actually rendered, so pages with no form stay untouched.
 */
function crm_forms_register_assets() {
	$src = crm_forms_embed_src();
	if ( '' === $src ) {
		return;
	}
	// Registered for the footer: the runtime mounts on DOMContentLoaded and
	// nothing on the page depends on it, so it never blocks rendering.
	// Bundle the reviewed renderer locally: a plugin upgrade gains stable retry
	// IDs immediately, independently of the CRM's hosted/embed deployment.
	wp_register_script( CRM_FORMS_HANDLE, plugins_url( 'embed.js', __FILE__ ), array(), CRM_FORMS_VERSION, true );
	$base = untrailingslashit( (string) get_option( CRM_FORMS_OPT_BASE, '' ) );
	$template = 'vercel' === get_option( CRM_FORMS_OPT_STYLE, 'nextjs' )
		? $base . '/api/crm-form?slug={slug}' : $base . '/api/crm/form/{slug}';
	wp_add_inline_script( CRM_FORMS_HANDLE, 'window.CrmFormsEndpoints=' . wp_json_encode(
		array( 'schema' => $template, 'submit' => $template ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
	) . ';', 'before' );
}
add_action( 'wp_enqueue_scripts', 'crm_forms_register_assets' );

/**
 * [crm_form slug="your-form-slug" style="none" class="my-wrapper"]
 *
 * style="none" suppresses the CRM's own stylesheet so the theme's form styles
 * apply instead — for people who want the form to match their site exactly.
 */
function crm_forms_shortcode( $atts ) {
	$atts = shortcode_atts(
		array(
			'slug'  => '',
			'style' => '',
			'class' => '',
		),
		$atts,
		'crm_form'
	);

	$slug = sanitize_title( $atts['slug'] );
	if ( '' === $slug ) {
		return current_user_can( 'edit_posts' )
			? '<p><strong>' . esc_html__( 'CRM Forms:', 'crm-forms' ) . '</strong> ' .
				esc_html__( 'add a slug, e.g. [crm_form slug="contact-us"].', 'crm-forms' ) . '</p>'
			: '';
	}

	if ( '' === crm_forms_embed_src() ) {
		return current_user_can( 'manage_options' )
			? '<p><strong>' . esc_html__( 'CRM Forms:', 'crm-forms' ) . '</strong> ' .
				esc_html__( 'set your CRM site URL under Settings → CRM Forms.', 'crm-forms' ) . '</p>'
			: '';
	}

	wp_enqueue_script( CRM_FORMS_HANDLE );

	$attributes = sprintf( ' data-crm-form="%s"', esc_attr( $slug ) );
	if ( 'none' === $atts['style'] ) {
		$attributes .= ' data-crm-style="none"';
	}
	if ( '' !== $atts['class'] ) {
		$attributes .= sprintf( ' class="%s"', esc_attr( $atts['class'] ) );
	}

	return '<div' . $attributes . '></div>';
}
add_shortcode( 'crm_form', 'crm_forms_shortcode' );

/**
 * Let the shortcode work in sidebar/footer text widgets too.
 */
add_filter( 'widget_text', 'do_shortcode' );

/* -------------------------------------------------------------------------
 * Settings screen
 * ---------------------------------------------------------------------- */

function crm_forms_settings_init() {
	register_setting(
		'crm_forms',
		CRM_FORMS_OPT_BASE,
		array(
			'type'              => 'string',
			'sanitize_callback' => 'crm_forms_sanitize_base_url',
			'default'           => '',
		)
	);
	register_setting(
		'crm_forms',
		CRM_FORMS_OPT_STYLE,
		array(
			'type'              => 'string',
			'sanitize_callback' => 'crm_forms_sanitize_style',
			'default'           => 'nextjs',
		)
	);
}
add_action( 'admin_init', 'crm_forms_settings_init' );

/**
 * Only http(s) origins, no trailing slash, no path smuggling.
 */
function crm_forms_sanitize_base_url( $value ) {
	$value = esc_url_raw( trim( (string) $value ), array( 'http', 'https' ) );
	if ( '' === $value ) { return ''; }
	$parts = wp_parse_url( $value );
	if ( ! is_array( $parts ) || 'https' !== ( $parts['scheme'] ?? '' ) || empty( $parts['host'] ) ||
		isset( $parts['user'] ) || isset( $parts['pass'] ) || isset( $parts['query'] ) || isset( $parts['fragment'] ) ||
		( isset( $parts['path'] ) && '/' !== $parts['path'] && '' !== $parts['path'] ) ) {
		add_settings_error( 'crm_forms', 'invalid_origin', __( 'Use an HTTPS CRM origin without a path, credentials, query or fragment.', 'crm-forms' ) );
		return (string) get_option( CRM_FORMS_OPT_BASE, '' );
	}
	return untrailingslashit( $value );
}

function crm_forms_sanitize_style( $value ) {
	return in_array( $value, array( 'nextjs', 'vercel' ), true ) ? $value : 'nextjs';
}

function crm_forms_menu() {
	add_options_page(
		__( 'CRM Forms', 'crm-forms' ),
		__( 'CRM Forms', 'crm-forms' ),
		'manage_options',
		'crm-forms',
		'crm_forms_settings_page'
	);
}
add_action( 'admin_menu', 'crm_forms_menu' );

function crm_forms_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$base  = get_option( CRM_FORMS_OPT_BASE, '' );
	$style = get_option( CRM_FORMS_OPT_STYLE, 'nextjs' );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'CRM Forms', 'crm-forms' ); ?></h1>
		<form action="options.php" method="post">
			<?php settings_fields( 'crm_forms' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">
						<label for="crm_forms_base"><?php esc_html_e( 'CRM site URL', 'crm-forms' ); ?></label>
					</th>
					<td>
						<input name="<?php echo esc_attr( CRM_FORMS_OPT_BASE ); ?>" id="crm_forms_base"
							type="url" class="regular-text" placeholder="https://crm.yourdomain.com"
							value="<?php echo esc_attr( $base ); ?>" />
						<p class="description">
							<?php esc_html_e( 'Where the CRM is deployed. No trailing slash.', 'crm-forms' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'API style', 'crm-forms' ); ?></th>
					<td>
						<select name="<?php echo esc_attr( CRM_FORMS_OPT_STYLE ); ?>">
							<option value="nextjs" <?php selected( $style, 'nextjs' ); ?>>
								<?php esc_html_e( 'Next.js  (/api/crm/embed)', 'crm-forms' ); ?>
							</option>
							<option value="vercel" <?php selected( $style, 'vercel' ); ?>>
								<?php esc_html_e( 'Vercel functions  (/api/crm-form?embed=1)', 'crm-forms' ); ?>
							</option>
						</select>
						<p class="description">
							<?php esc_html_e( 'Match the adapter the CRM was deployed with.', 'crm-forms' ); ?>
						</p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>

		<h2><?php esc_html_e( 'Using it', 'crm-forms' ); ?></h2>
		<p><?php esc_html_e( 'Publish a form in the CRM admin, then put its slug in a shortcode:', 'crm-forms' ); ?></p>
		<p><code>[crm_form slug="contact-us"]</code></p>
		<p>
			<?php esc_html_e( 'Works in the block editor (Shortcode block), the classic editor, text widgets, and page builders such as Elementor and Divi. In a PHP template:', 'crm-forms' ); ?>
		</p>
		<p><code>&lt;?php echo do_shortcode( '[crm_form slug="contact-us"]' ); ?&gt;</code></p>
		<p>
			<?php esc_html_e( 'To drop the CRM styling and let your theme style the fields instead:', 'crm-forms' ); ?>
			<code>[crm_form slug="contact-us" style="none"]</code>
		</p>
		<p>
			<?php esc_html_e( 'Editing the form in the CRM updates every page it appears on — you never re-paste anything.', 'crm-forms' ); ?>
		</p>
	</div>
	<?php
}

/**
 * Page builders that inject markup over AJAX render the container after the
 * loader has already scanned the page; this re-scan mounts anything new.
 */
function crm_forms_footer_rescan() {
	if ( ! wp_script_is( CRM_FORMS_HANDLE, 'enqueued' ) ) {
		return;
	}
	wp_add_inline_script(
		CRM_FORMS_HANDLE,
		'document.addEventListener("crm-forms:refresh",function(){window.CrmForms&&window.CrmForms.refresh()});'
	);
}
// The local loader handles crm-forms:refresh itself, including late shortcodes.
